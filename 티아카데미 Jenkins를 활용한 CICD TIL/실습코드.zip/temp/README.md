# Lecture

## Website

```sh
```

## Server

```sh
npm init
npm install -D typescript
npm i -S express jest
```
