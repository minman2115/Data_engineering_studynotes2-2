const a = 'dfsdf';
console.log(a)