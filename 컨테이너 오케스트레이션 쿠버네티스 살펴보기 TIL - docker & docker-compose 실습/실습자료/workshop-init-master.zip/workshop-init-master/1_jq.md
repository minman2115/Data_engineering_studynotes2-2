# jq

Command-line JSON processor 

https://github.com/stedolan/jq


```sh
sudo apt install -y jq

# check
jq
```
